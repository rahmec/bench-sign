#ifndef MIRATH_TCITH_MIRATH_KEYGEN_H
#define MIRATH_TCITH_MIRATH_KEYGEN_H

#include <stddef.h>
#include <stdint.h>

int mirath_keygen(uint8_t *pk, uint8_t *sk);

#endif //MIRATH_TCITH_MIRATH_KEYGEN_H
